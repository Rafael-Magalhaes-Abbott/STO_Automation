import subprocess       # Para executar os scripts VBS
import pandas as pd     # Para ler e escrever arquivos Excel
from time import sleep as wait            # Para controlar pausas entre execuções
import os               # Para manipulação de caminhos e arquivos
import sys
from tkinter import Tk
from tkinter.filedialog import askopenfilename
from tkinter import messagebox
import tkinter as tk
from dateutil import parser
import openpyxl
import logging
from datetime import datetime



# Function to run the VB scripts
def RunVB(VBsPath, variaveis):
    """
    Executa um script VBS com uma lista de variáveis como argumentos.

    Args:
        VBsPath (str): Caminho completo para o script VBS.
        variaveis (list): Lista de variáveis a serem passadas como argumentos para o VBS.

    Returns:
        str: Saída padrão (stdout) do script VBS.
    """
    # Constrói a linha de comando com os argumentos
    argumentos = [VBsPath] + [str(v) for v in variaveis]

    # Executa o script com os argumentos
    comando = ["cscript.exe", "//NoLogo"] + argumentos
    resultado = subprocess.run(comando, capture_output=True, text=True)

    # Retorna a saída do script
    return resultado.stdout.strip()


# Function to prompt user to select a file
def select_file():
    # Cria uma janela oculta do Tkinter
    root = Tk()
    root.withdraw()

    # Abre o seletor de arquivos
    caminho_arquivo = askopenfilename(
        title="Select the file",
        filetypes=[("Arquivos Excel", "*.xlsx *.xls")]
    )

    return caminho_arquivo


# function to read the selected file
def read_file(caminho_arquivo):
    try:
        df = pd.read_excel(caminho_arquivo)
        print("File loaded successfully!")
        print("Available columns:", df.columns.tolist())
        return df
    except Exception as e:
        print("error reading file:", e)
        return None
    

# get sap creds
def get_sap_credentials():
    def submit():
        nonlocal sap_user, sap_password
        sap_user = user_entry.get()
        sap_password = pass_entry.get()
        if not sap_user or not sap_password:
            messagebox.showwarning("Error", "Username and Password are needed")
        else:
            login_window.destroy()

    sap_user = ""
    sap_password = ""

    login_window = tk.Tk()
    login_window.title("Enter your SAP Credentials")
    login_window.geometry("300x150")
    login_window.resizable(False, False)

    tk.Label(login_window, text="User:").pack(pady=(10, 0))
    user_entry = tk.Entry(login_window)
    user_entry.pack()

    tk.Label(login_window, text="Password:").pack(pady=(10, 0))
    pass_entry = tk.Entry(login_window, show="*")
    pass_entry.pack()

    tk.Button(login_window, text="Entrar", command=submit).pack(pady=10)

    login_window.mainloop()

    return sap_user, sap_password


from dateutil import parser

def formatDate(date_input):
    """
    Converte uma data em qualquer formato reconhecível para 'MM/dd/yyyy'.
    
    Parâmetros:
        date_input (str): Data em formato string (ex: '2025-06-06', '06/06/2025', etc.)
    
    Retorna:
        str: Data formatada como 'MM/dd/yyyy'
    """
    try:
        date_obj = parser.parse(str(date_input))
        return date_obj.strftime("%m/%d/%Y")
    except Exception as e:
        return f"Erro ao converter data: {e}"
    


def update_excel(file_path, unique_id, message):
    # Carrega o arquivo Excel
    df = pd.read_excel(file_path, engine='openpyxl')
    
    # Localiza as linhas onde a coluna 'Unique ID' contém o valor específico
    mask = df['Unique ID'] == unique_id
    
    # Escreve a mensagem na coluna H (cria a coluna se não existir)
    
    df['Message'] = df['Message'].astype('object')
    df.loc[mask, 'Message'] = message
    
    # Salva o arquivo com as alterações
    df.to_excel(file_path, index=False, engine='openpyxl')


def ensure_message_column(file_path):
    # Carrega o arquivo Excel
    df = pd.read_excel(file_path, engine='openpyxl')
    
    # Verifica se a coluna 'Message' existe
    if 'Message' not in df.columns:
        # Adiciona a coluna 'Message' com valores vazios
        df['Message'] = ""
        print("Column 'message' was created on input file\n")
    
    # Salva o arquivo atualizado
    df.to_excel(file_path, index=False, engine='openpyxl')


def delete_files(folder_path):
    # Lista todos os arquivos na pasta
    files = os.listdir(folder_path)
    
    # Itera sobre os arquivos e remove cada um
    for file in files:
        file_path = os.path.join(folder_path, file)
        if os.path.isfile(file_path):
            os.remove(file_path)
            # print(f"Deleted file: {file_path}")



def setup_logging(log_folder):
    if not os.path.exists(log_folder):
        os.makedirs(log_folder)

    now = datetime.now()
    log_filename = f"logfile_{now.strftime('%m%d%H%M')}.txt"
    log_path = os.path.join(log_folder, log_filename)

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_path),
            logging.StreamHandler(sys.stdout)
        ]
    )

    class LoggerWriter:
        def __init__(self, logger, level):
            self.logger = logger
            self.level = level
            self.buffer = ''

        def write(self, message):
            if message != '\n':
                self.buffer += message
                if '\n' in self.buffer:
                    self.logger.log(self.level, self.buffer.strip())
                    self.buffer = ''

        def flush(self):
            if self.buffer:
                self.logger.log(self.level, self.buffer.strip())
                self.buffer = ''

    sys.stdout = LoggerWriter(logging.getLogger('STDOUT'), logging.INFO)
    sys.stderr = LoggerWriter(logging.getLogger('STDERR'), logging.ERROR)

    return log_path


def format_material(num):
    return str(num).zfill(5)









