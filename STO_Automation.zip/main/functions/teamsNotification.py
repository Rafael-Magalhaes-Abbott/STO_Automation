import requests
import base64



def sendTeamsMessage(email, message, filename, filedata):
    # Dados para enviar ao Power Automate
    dados = {
        "email": email,  # E-mail do destinatário no Teams
        "mensagem": message,
        "nome_arquivo": filename,
        "conteudo_base64": filedata
    }

    url = r"https://prod-45.westus.logic.azure.com:443/workflows/60a8a1d831414dd9914995d7e88fe57a/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=ESl-3jPYLrgBa4V94-nm-l_a-EshJypkw1bHWN05LV0"
    # Envia a requisição
    resposta = requests.post(url, json=dados)

    # Verifica o resultado
    if resposta.status_code == 200 or resposta.status_code == 202:
        print("Mensagem enviada com sucesso!\n")
    else:
        print(f"Erro ao enviar: {resposta.status_code} - {resposta.text}")


def convertFiletoBase64(filepath):

    # Lê o arquivo em modo binário e converte para base64
    with open(filepath, "rb") as file:
        base64_data = base64.b64encode(file.read()).decode("utf-8")

        return base64_data
    








