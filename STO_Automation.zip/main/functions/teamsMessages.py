# using this file to keep all the messages that might be sent on teams

processStart = """The process was successfully configured and will start to process the STOs"""

processEnd = f"""The Automation finished processing the STOs"""
