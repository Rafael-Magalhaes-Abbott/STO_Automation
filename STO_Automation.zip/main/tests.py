import subprocess       
import pandas as pd     
from time import sleep as wait            
import os               
import sys
from tkinter import Tk
from tkinter.filedialog import askopenfilename
from tkinter import messagebox
from functions import functions as func
import keyboard
import pyautogui as ag
from functions import teamsNotification as tn

# Set Path variables
projectFolder = r"C:\Projetos_Lighthouse\STO_Automation"
mainFolder = projectFolder + r"\main"
inputFolder = projectFolder + r"\input"
dataFolder = projectFolder + r"\data"
archiveFolder = dataFolder + r"archive"
scriptsFolder = dataFolder + r"\scripts"
tempFolder = dataFolder + r"\temp"
userdataFolder = projectFolder + r"\userdata"

out = func.RunVB(scriptsFolder + r"\clickButton.vbs", ["a"])
print(out)