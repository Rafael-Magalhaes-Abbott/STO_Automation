import os
import zipfile
import subprocess
import subprocess
import sys

# Verifica se a biblioteca 'requests' está instalada
try:
    import requests
except ImportError:
    print("Biblioteca 'requests' não encontrada. Instalando...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
    import requests  # tenta importar novamente após a instalação




try:
    # URL do arquivo .zip no GitHub
    url = "https://github.com/Rafael-Magalhaes-Abbott/STO_Automation/raw/main/STO_Automation.zip"

    # Caminho onde os arquivos serão extraídos
    extract_to = r"C:\Projetos_Lighthouse\STO_Automation"
    reqsPath = extract_to + r"\data\archive\requirements.txt"

    # Nome do arquivo .zip temporário
    zip_path = "STO_Automation.zip"
    
    print("Baixando o arquivo .zip......")
    response = requests.get(url)
    response.raise_for_status()

    with open(zip_path, "wb") as file:
        file.write(response.content)
    print("Download concluído.")

    # Cria o diretório se não existir
    if not os.path.exists(extract_to):
        os.makedirs(extract_to)
        print(f"Diretório {extract_to} criado.")

    print("Extraindo os arquivos...")
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(extract_to)
    print("Extração concluída.")

    # Instala as dependências do requirements.txt
    if os.path.exists(reqsPath):
        print("Instalando dependências do requirements.txt...")
        subprocess.check_call(['pip', 'install', '-r', reqsPath])
        print("Dependências instaladas.")
    else:
        print("Arquivo requirements.txt não encontrado.")

except requests.exceptions.RequestException as e:
    print(f"Erro ao baixar o arquivo: {e}")
except zipfile.BadZipFile as e:
    print(f"Erro ao extrair o arquivo .zip: {e}")
except subprocess.CalledProcessError as e:
    print(f"Erro ao instalar dependências: {e}")
except Exception as e:
    print(f"Ocorreu um erro: {e}")
finally:
    if os.path.exists(zip_path):
        os.remove(zip_path)
    print("Processo concluído.")
    input('Press Enter to Exit...')

