import os
import zipfile
import subprocess
import sys

# Lista de bibliotecas necessárias
required_packages = [
    "pandas",
    "pyautogui",
    "python-dateutil",
    "openpyxl"
]

# Instala as bibliotecas, se necessário
for package in required_packages:
    try:
        __import__(package.replace("-", "_"))
    except ImportError:
        print(f"Instalando {package}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# Verifica se a biblioteca 'requests' está instalada
try:
    import requests
except ImportError:
    print("Biblioteca 'requests' não encontrada. Instalando...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])
    import requests

# URL do arquivo .zip no GitHub
url = "https://github.com/Rafael-Magalhaes-Abbott/STO_Automation/raw/main/STO_Automation.zip"
# Caminho onde os arquivos serão extraídos
extract_to = r"C:\Projetos_Lighthouse\STO_Automation"
# Nome do arquivo .zip temporário
zip_path = "STO_Automation.zip"

try:
    print("Baixando o arquivo .zip......")
    response = requests.get(url)
    response.raise_for_status()
    with open(zip_path, "wb") as file:
        file.write(response.content)
    print("Download concluído.")

    # Remove arquivos antigos do diretório de extração
    if os.path.exists(extract_to):
        print("Removendo arquivos antigos...")
        for root, dirs, files in os.walk(extract_to, topdown=False):
            for name in files:
                os.remove(os.path.join(root, name))
            for name in dirs:
                os.rmdir(os.path.join(root, name))
        print("Arquivos antigos removidos.")
    else:
        os.makedirs(extract_to)
        print(f"Diretório {extract_to} criado.")

    print("Extraindo os arquivos...")
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(extract_to)
    print("Extração concluída.")

except requests.exceptions.RequestException as e:
    print(f"Erro ao baixar o arquivo: {e}")
except zipfile.BadZipFile as e:
    print(f"Erro ao extrair o arquivo .zip: {e}")
except subprocess.CalledProcessError as e:
    print(f"Erro ao instalar dependências: {e}")
except Exception as e:
    print(f"Error: {e}")
finally:
    if os.path.exists(zip_path):
        os.remove(zip_path)
    print("Done")

input('Press Enter to Exit')
